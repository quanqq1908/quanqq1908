<div class="clear">
        
    </div>
    <div class="footer">
        <p>Copy right by Quân</p>
    </div>