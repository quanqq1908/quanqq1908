<ul class ="admincp_list">
    <li><a href="">Quản lý danh mục sản phẩm</a></li>
    <li><a href="">Quản lý sản phẩm</a></li>
    <li><a href="">Quản lý bài viết</a></li>
    <li><a href="">Quản lý danh mục bài viết</a></li>
</ul>