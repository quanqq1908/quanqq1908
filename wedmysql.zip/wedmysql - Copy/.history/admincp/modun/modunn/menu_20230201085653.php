<ul class="ad_list">
    <li><a href="indexxx.php?action=quanlydanhmucsanpham">Quản lý danh mục sản phẩm</a></li>
    <li><a href="indexxx.php?action=quanlysanpham">Quản lý sản phẩm</a></li>
    <li><a href="indexxx.php?action=quanlybaiviet">Quản lý bài viết</a></li>
    <li><a href="indexxx.php?action=quanlydanhmucbaiviet">Quản lý danh mục bài viết</a></li>
</ul>