<div class="clear">
    
</div>
<div class="main"></div>
 