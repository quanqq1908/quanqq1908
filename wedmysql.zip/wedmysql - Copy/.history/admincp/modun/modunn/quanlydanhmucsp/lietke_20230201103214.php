<p>Liệt kê danh mục sản phẩm</p>
<table style="width:100%" border="1" style="border-collapse:collapse" >
  <tr>
    <th>tên danh mục</th>
    <th>Thứ tự</th>
    <th>Country</th>
  </tr>
  <tr>
    <td>Alfreds Futterkiste</td>
    <td>Maria Anders</td>
   
  </tr>
</table>