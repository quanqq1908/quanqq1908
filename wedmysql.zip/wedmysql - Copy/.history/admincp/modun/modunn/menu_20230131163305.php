<ul>
    <li><a href="">Quản lý danh mục sản phẩm</a></li>
</ul>