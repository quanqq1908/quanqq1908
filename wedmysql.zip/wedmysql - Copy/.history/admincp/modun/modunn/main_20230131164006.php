<div class="clear">
    <p>Main ad</p> 
</div>
 