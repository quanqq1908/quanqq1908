<div class="wrapper">
<table border="1">
    <tr>
        <td>Tài khoản</td>
        <td>Mật khẩu</td>
    </tr>
    <tr>
        <td></td>
        <td></td>
    </tr>
</table>
</div>