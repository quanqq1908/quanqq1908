<div class="wrapper">
<table border="1">
    <tr>
        <td>Tài khoản</td>
        <td></td>
    </tr>
    <tr>
        <td>Mật khẩu</td>
        <td></td>
    </tr>
</table>
</div>