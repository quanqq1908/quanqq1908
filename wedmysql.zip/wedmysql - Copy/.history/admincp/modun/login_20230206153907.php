<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng nhập</title>
</head>
<body>
<div class="wrapper">
<table border="1">
    <tr>
        <td>Tài khoản</td>
        <td><input type="text" name="username"></td>
    </tr>
    <tr>
        <td><input type="text" name="username">Mật khẩu</td>
        <td></td>
    </tr>
</table>
</div>
</body>
</html>
